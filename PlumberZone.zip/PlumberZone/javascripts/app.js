$(document).ready(function(){
	$('.sleekslider').sleekslider({
		thumbs: ['wallhaven-27263-thumbnail.jpg','wallhaven-3178-thumb.jpg', 'wallhaven-16270-thumbnail.jpg'],
		labels:['Title Goes Here', 'Title Goes Here', 'Title Goes Here'],
		speed: 10000
	});
})