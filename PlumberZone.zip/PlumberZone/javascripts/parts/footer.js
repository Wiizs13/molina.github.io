document.write(`
<div class="footer-middle">
<div class="container">
    <div class="row">
        <div class="col-sm-6 col-md-3">
            <div class="row">
                <div class="widget w-plr-post">
                    <h3 class="title">About Us</h3>
                    <div class="excerpt">Proactively incentivize superior benefits and resource maximizing supply chains. Efficiently transform interoperable interfaces.</div>
                    <address class="address">
                        <ul>
                            <li><span><i class="fa fa-home"></i></span> New Chokey Road, USA.</li>
                            <li><span><i class="fa fa-phone"></i></span> +088 0100 000000.</li>
                            <li><span><i class="fa fa-envelope-o"></i></span> <a href="">www.contact@yourmail.com</a></li>
                            <li><span><i class="fa fa-globe"></i></span> <a href="">www.yourwebsite.com</a></li>
                        </ul>
                    </address>
                </div><!-- /.widget -->
            </div>
        </div>

        
        <div class="col-xs-6 col-sm-6 col-md-2">
            <div class="widget wtps">
                <h3 class="title">Top Services</h3>

                <ul class="top-service">
                    <li><a href="#"><i class="fa fa-angle-right"></i>Clogged Drains</a></li>
                    <li><a href="#"><i class="fa fa-angle-right"></i>Camera Inspection</a></li>
                    <li><a href="#"><i class="fa fa-angle-right"></i>Sewage Backups</a></li>
                    <li><a href="#"><i class="fa fa-angle-right"></i>Plumbing Repairs</a></li>
                    <li><a href="#"><i class="fa fa-angle-right"></i>Frozen Pipes</a></li>
                    <li><a href="#"><i class="fa fa-angle-right"></i>Common Repairs</a></li>
                    <li><a href="#"><i class="fa fa-angle-right"></i>Trenchless Pipe</a></li>
                </ul>
            </div><!-- /.widget -->
        </div>


        <div class="col-xs-6 col-sm-6 col-md-4">
            <div class="row">
                <div class="footer-right">
                    <div class="footer-right-image">
                        <img src="images/footer/footer-big.png" alt="image">
                    </div>
                </div>
            </div><!-- /.row -->
        </div><!-- /.col-md-4 -->
    </div><!-- /.row -->
</div><!-- /.container -->
</div><!-- /.footer-middle -->
<div class="footer-bottom">
<div class="container">
    <div class="row">
        <div class="footer-bottom-left">
            <p>Copyright &copy; 2022. Design and Developed by <a href="single.html">Al3x</a></p>
        </div>
        <div class="footer-bottom-right">
            <a href="single.html" class="term-condition"> Terms and Conditions</a>
            <a href="#" class="privacy-policy"> Privacy Policy</a>
            <ul class="social-media">
                <li><a href="www.facebook.com" class="facebook"><i class="fa fa-facebook"></i></a></li>
                <li><a href="www.twitter.com" class="twitter"><i class="fa fa-twitter"></i></a></li>
                <li><a href="www.likedin.com" class="linkedin"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="www.vimeo.com" class="vimeo"><i class="fa fa-vimeo"></i></a></li>
            </ul>
        </div>
    </div><!-- /.row -->
</div><!-- /.container -->
</div><!-- /.footer-bottom -->

`);