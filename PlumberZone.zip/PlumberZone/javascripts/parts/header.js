document.write(`
<!-- start header  -->
<header id="header">
    <div class="header-top">
        <div class="container">
            <div class="row">
                <div class="logo">
                    <a href="index.html"><img src="assets/images/logo.png" alt="Logo"></a>
                </div><!-- /.logo -->

                <div class="contact-place">
                    <div class="cp-01 phone">
                        <div class="cp-inner">
                            <div class="icon flaticon-phone41"></div>
                            <div class="phone-text">
                                <span class="text">Call Us Now</span>
                                <span class="numbers">+1 (301)613-9367</span>
                            </div>
                        </div>
                    </div><!--  end phone -->

                    <div class="cp-01 mail">
                        <div class="cp-inner">
                            <div class="icon flaticon-email19"></div>
                            <div class="phone-text">
                                <span class="text">Contact with E-mail</span>
                                <a href="#" class="numbers">saulmolina49@gmail.com</a>
                            </div>
                        </div>    
                    </div><!--  end phone -->
                </div><!-- /.contact-place -->

                <div class="top-social-media">
                    <ul class="social-media">
                        <li><a href="#" class="facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#" class="vimeo"><i class="fa fa-vimeo"></i></a></li>
                    </ul>
                </div><!-- /.top-social-media -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </div><!-- /.header-top -->

    <div class="header-bottom">
        <div class="primary-menu">
            <div class="container">
                <div class="row">
                    <div class="menu">
                        <div class="menu-inner">
                            <div class="navbar-header ">
                                <a href="index.html" class="menu-logo"><img src="assets/images/menu-logo.png" alt="Logo"></a>
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                    <i class="fa fa-bars"></i>
                                </button>
                            </div><!-- /.menu-logo -->
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul class="navbar-menu">
                              
                                <li><a href="index.html"><span>Home</span></a></li>
                                <li><a href="about.html"><span>About Us</span></a></li>
                                <li><a href="service.html">Service</a></li>
                                 <li><a href="portfolio-style1.html">Portfolio</a></li>  
                                <li><a href="contact.html"><span>Contact</span></a></li>
                            </ul>
                            <div class="search-icon">
                                <i class="fa fa-search"></i>
                            </div>
                            </div>
                        </div><!--  end menu-inner  -->
                    </div><!-- end menu  -->
                </div><!--  end row  -->
            </div><!--  end container  -->
        </div><!-- end primary menu -->
    </div><!-- /.header-bottom -->
</header>
`);